#include <iostream>
#include <string>
using namespace std;

const int MAX_PATIENTS = 100;
const int MAX_DOCTORS = 50;
const int MAX_APPOINTMENTS = 200;

// Patient class
class Patient {
private:
    int patientID;
    string name;
    int age;
    string medicalHistory;

public:
    Patient() {
        patientID = 0;
        name = "";
        age = 0;
        medicalHistory = "";
    }

    void setPatient(int id, string n, int a, string history) {
        patientID = id;
        name = n;
        age = a;
        medicalHistory = history;
    }

    void display() {
        cout << "Patient ID: " << patientID << "\nName: " << name
             << "\nAge: " << age << "\nMedical History: " << medicalHistory << endl;
    }

    int getID() { return patientID; }
    string getName() { return name; }
};

// Doctor class
class Doctor {
private:
    int doctorID;
    string name;
    string specialty;

public:
    Doctor() {
        doctorID = 0;
        name = "";
        specialty = "";
    }

    void setDoctor(int id, string n, string spec) {
        doctorID = id;
        name = n;
        specialty = spec;
    }

    void display() {
        cout << "Doctor ID: " << doctorID << "\nName: " << name
             << "\nSpecialty: " << specialty << endl;
    }

    int getID() { return doctorID; }
    string getName() { return name; }
};

// Appointment class
class Appointment {
private:
    int appointmentID;
    int patientID;
    int doctorID;
    string date;
    string time;

public:
    Appointment() {
        appointmentID = 0;
        patientID = 0;
        doctorID = 0;
        date = "";
        time = "";
    }

    void setAppointment(int id, int pID, int dID, string dt, string tm) {
        appointmentID = id;
        patientID = pID;
        doctorID = dID;
        date = dt;
        time = tm;
    }

    void display(const Patient patients[], int pCount, const Doctor doctors[], int dCount) {
        cout << "Appointment ID: " << appointmentID << endl;
        cout << "Date: " << date << " Time: " << time << endl;

        // Find and display patient info
        for (int i = 0; i < pCount; i++) {
            if (patients[i].getID() == patientID) {
                cout << "Patient Info:\n";
                patients[i].display();
                break;
            }
        }

        // Find and display doctor info
        for (int i = 0; i < dCount; i++) {
            if (doctors[i].getID() == doctorID) {
                cout << "Doctor Info:\n";
                doctors[i].display();
                break;
            }
        }
    }
};

// Function declarations
void addPatient(Patient patients[], int &pCount);
void addDoctor(Doctor doctors[], int &dCount);
void addAppointment(Appointment appointments[], int &aCount, Patient patients[], int pCount, Doctor doctors[], int dCount);
void showPatients(const Patient patients[], int pCount);
void showDoctors(const Doctor doctors[], int dCount);
void showAppointments(const Appointment appointments[], int aCount, Patient patients[], int pCount, Doctor doctors[], int dCount);

int main() {
    Patient patients[MAX_PATIENTS];
    Doctor doctors[MAX_DOCTORS];
    Appointment appointments[MAX_APPOINTMENTS];

    int patientCount = 0;
    int doctorCount = 0;
    int appointmentCount = 0;

    int choice;

    do {
        cout << "\nHospital Management System\n";
        cout << "1. Add Patient\n2. Add Doctor\n3. Add Appointment\n";
        cout << "4. Show Patients\n5. Show Doctors\n6. Show Appointments\n";
        cout << "0. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        cin.ignore(); // Clear input buffer

        switch(choice) {
            case 1:
                if(patientCount < MAX_PATIENTS)
                    addPatient(patients, patientCount);
                else
                    cout << "Patient list full!\n";
                break;

            case 2:
                if(doctorCount < MAX_DOCTORS)
                    addDoctor(doctors, doctorCount);
                else
                    cout << "Doctor list full!\n";
                break;

            case 3:
                if(appointmentCount < MAX_APPOINTMENTS)
                    addAppointment(appointments, appointmentCount, patients, patientCount, doctors, doctorCount);
                else
                    cout << "Appointment list full!\n";
                break;

            case 4:
                showPatients(patients, patientCount);
                break;

            case 5:
                showDoctors(doctors, doctorCount);
                break;

            case 6:
                showAppointments(appointments, appointmentCount, patients, patientCount, doctors, doctorCount);
                break;

            case 0:
                cout << "Exiting program.\n";
                break;

            default:
                cout << "Invalid choice, try again.\n";
        }

    } while(choice != 0);

    return 0;
}

// Function definitions

void addPatient(Patient patients[], int &pCount) {
    int id, age;
    string name, history;

    cout << "Enter patient ID: ";
    cin >> id;
    cin.ignore();

    cout << "Enter patient name: ";
    getline(cin, name);

    cout << "Enter patient age: ";
    cin >> age;
    cin.ignore();

    cout << "Enter medical history: ";
    getline(cin, history);

    patients[pCount].setPatient(id, name, age, history);
    pCount++;

    cout << "Patient added successfully.\n";
}

void addDoctor(Doctor doctors[], int &dCount) {
    int id;
    string name, specialty;

    cout << "Enter doctor ID: ";
    cin >> id;
    cin.ignore();

    cout << "Enter doctor name: ";
    getline(cin, name);

    cout << "Enter specialty: ";
    getline(cin, specialty);

    doctors[dCount].setDoctor(id, name, specialty);
    dCount++;

    cout << "Doctor added successfully.\n";
}

void addAppointment(Appointment appointments[], int &aCount, Patient patients[], int pCount, Doctor doctors[], int dCount) {
    int id, pID, dID;
    string date, time;

    cout << "Enter appointment ID: ";
    cin >> id;
    cout << "Enter patient ID: ";
    cin >> pID;
    cout << "Enter doctor ID: ";
    cin >> dID;
    cin.ignore();

    // Validate patient ID
    bool patientFound = false;
    for (int i = 0; i < pCount; i++) {
        if (patients[i].getID() == pID) {
            patientFound = true;
            break;
        }
    }
    if (!patientFound) {
        cout << "Patient ID not found.\n";
        return;
    }

    // Validate doctor ID
    bool doctorFound = false;
    for (int i = 0; i < dCount; i++) {
        if (doctors[i].getID() == dID) {
            doctorFound = true;
            break;
        }
    }
    if (!doctorFound) {
        cout << "Doctor ID not found.\n";
        return;
    }

    cout << "Enter date (YYYY-MM-DD): ";
    getline(cin, date);
    cout << "Enter time (HH:MM): ";
    getline(cin, time);

    appointments[aCount].setAppointment(id, pID, dID, date, time);
    aCount++;

    cout << "Appointment added successfully.\n";
}

void showPatients(const Patient patients[], int pCount) {
    cout << "\n--- Patients List ---\n";
    for (int i = 0; i < pCount; i++) {
        patients[i].display();
        cout << "---------------------\n";
    }
}

void showDoctors(const Doctor doctors[], int dCount) {
    cout << "\n--- Doctors List ---\n";
    for (int i = 0; i < dCount; i++) {
        doctors[i].display();
        cout << "---------------------\n";
    }
}

void showAppointments(const Appointment appointments[], int aCount, Patient patients[], int pCount, Doctor doctors[], int dCount) {
    cout << "\n--- Appointments List ---\n";
    for (int i = 0; i < aCount; i++) {
        appointments[i].display(patients, pCount, doctors, dCount);
        cout << "---------------------\n";
    }
}

