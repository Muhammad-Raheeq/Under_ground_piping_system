#include <iostream>
#include <QApplication>
#include <QMainWindow>
#include <QTableWidget>
#include <QPushButton>
#include <QLineEdit>
#include <QTextEdit>
#include <QLabel>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QMessageBox>

class Patient {
    int patientID;
    QString name;
    int age;
    QString medicalHistory;

public:
    Patient(int id = 0, const QString& n = "", int a = 0, const QString& history = "")
        : patientID(id), name(n), age(a), medicalHistory(history) {}

    int getID() const { return patientID; }
    QString getName() const { return name; }
    int getAge() const { return age; }
    QString getMedicalHistory() const { return medicalHistory; }
};

class MainWindow : public QMainWindow {
    Q_OBJECT

    QList<Patient> patients;

    QLineEdit* idEdit;
    QLineEdit* nameEdit;
    QLineEdit* ageEdit;
    QTextEdit* historyEdit;
    QTableWidget* table;
    QPushButton* addButton;

public:
    MainWindow() {
        QWidget* centralWidget = new QWidget(this);
        setCentralWidget(centralWidget);

        // Layouts
        QVBoxLayout* mainLayout = new QVBoxLayout(centralWidget);
        QHBoxLayout* formLayout = new QHBoxLayout();
        QVBoxLayout* labelsLayout = new QVBoxLayout();
        QVBoxLayout* inputsLayout = new QVBoxLayout();

        // Labels
        labelsLayout->addWidget(new QLabel("Patient ID:"));
        labelsLayout->addWidget(new QLabel("Name:"));
        labelsLayout->addWidget(new QLabel("Age:"));
        labelsLayout->addWidget(new QLabel("Medical History:"));

        // Inputs
        idEdit = new QLineEdit();
        nameEdit = new QLineEdit();
        ageEdit = new QLineEdit();
        historyEdit = new QTextEdit();
        historyEdit->setFixedHeight(60);

        inputsLayout->addWidget(idEdit);
        inputsLayout->addWidget(nameEdit);
        inputsLayout->addWidget(ageEdit);
        inputsLayout->addWidget(historyEdit);

        formLayout->addLayout(labelsLayout);
        formLayout->addLayout(inputsLayout);

        mainLayout->addLayout(formLayout);

        addButton = new QPushButton("Add Patient");
        mainLayout->addWidget(addButton);

        // Table for patients
        table = new QTableWidget(0, 4);
        QStringList headers = {"Patient ID", "Name", "Age", "Medical History"};
        table->setHorizontalHeaderLabels(headers);
        table->setEditTriggers(QAbstractItemView::NoEditTriggers);
        mainLayout->addWidget(table);

        setWindowTitle("Hospital Management System - Patients");

        connect(addButton, &QPushButton::clicked, this, &MainWindow::addPatient);
    }

private slots:
    void addPatient() {
        bool okID, okAge;
        int id = idEdit->text().toInt(&okID);
        if (!okID) {
            QMessageBox::warning(this, "Input Error", "Please enter a valid numeric Patient ID.");
            return;
        }

        QString name = nameEdit->text();
        if (name.isEmpty()) {
            QMessageBox::warning(this, "Input Error", "Name cannot be empty.");
            return;
        }

        int age = ageEdit->text().toInt(&okAge);
        if (!okAge || age <= 0) {
            QMessageBox::warning(this, "Input Error", "Please enter a valid age.");
            return;
        }

        QString history = historyEdit->toPlainText();

        // Check duplicate patient ID
        for (const Patient& p : patients) {
            if (p.getID() == id) {
                QMessageBox::warning(this, "Duplicate Error", "Patient ID already exists.");
                return;
            }
        }

        patients.append(Patient(id, name, age, history));
        updateTable();

        // Clear inputs
        idEdit->clear();
        nameEdit->clear();
        ageEdit->clear();
        historyEdit->clear();
    }

    void updateTable() {
        table->setRowCount(patients.size());
        for (int i = 0; i < patients.size(); ++i) {
            table->setItem(i, 0, new QTableWidgetItem(QString::number(patients[i].getID())));
            table->setItem(i, 1, new QTableWidgetItem(patients[i].getName()));
            table->setItem(i, 2, new QTableWidgetItem(QString::number(patients[i].getAge())));
            table->setItem(i, 3, new QTableWidgetItem(patients[i].getMedicalHistory()));
        }
    }
};

#include "main.moc"

int main(int argc, char *argv[]) {
    QApplication app(argc, argv);
    MainWindow w;
    w.show();
    return app.exec();
}
